let cart = [];

function showCategory(category) {
    let productsHTML = '';

    if (category === 'anarkali') {
        productsHTML = getProductHTML([
            { img: "https://i.ibb.co/5W3KDVGP/anarkali-1.jpg", price: 899 },
            { img: "https://i.ibb.co/n4YmTsp/anarkali-2.jpg", price: 699 },
            { img: "https://i.ibb.co/prBFw3Sf/anarkali-3.jpg", price: 799 },
            { img: "https://i.ibb.co/SXJs1m8Y/anarkali-4.jpg", price: 999 },
            { img: "https://i.ibb.co/nxn3Kvs/anarkali-5.jpg", price: 699 },
            { img: "https://i.ibb.co/N6c8kLtd/anarkali-6.jpg", price: 799 },
            { img: "https://i.ibb.co/pvPZjYn7/anarkali-7.jpg", price: 999 }
        ]);
    } else if (category === 'saree') {
        productsHTML = getProductHTML([
            { img: "https://i.ibb.co/7xckvb70/saree-1.jpg", price: 799 },
            { img: "https://i.ibb.co/0yvr0XsY/saree-3.jpg", price: 899 },
            { img: "https://i.ibb.co/DPc8Y8Kj/saree-4.jpg", price: 999 },
            { img: "https://i.ibb.co/N2J2J8yM/saree-5.jpg", price: 899 },
            { img: "https://i.ibb.co/bjk0RTf8/saree-6.jpg", price: 999 }
        ]);
    } else if (category === 'kurti') {
        productsHTML = getProductHTML([
            { img: "https://i.ibb.co/tPv0Jrh2/kurti-2.jpg", price: 499 },
            { img: "https://i.ibb.co/RGsc233T/kurti-3.jpg", price: 499 },
            { img: "https://i.ibb.co/nsZ0TYMs/kurti-4.jpg", price: 599 },
            { img: "https://i.ibb.co/fVGjJF2V/kurti-5.jpg", price: 699 },
            { img: "https://i.ibb.co/8wkFxWX/kurti-6.jpg", price: 599 },
            { img: "https://i.ibb.co/cSw8G4j5/kurti-7.jpg", price: 599 },
            { img: "https://i.ibb.co/qMWdKT7J/kurti-8.jpg", price: 499 }
        ]);
    }

    document.getElementById("products").innerHTML = productsHTML;
}

function getProductHTML(products) {
    return products.map((product, index) => `
        <div class="product">
            <img src="${product.img}" alt="Product">
            <p>₹${product.price}</p>
            <input type="number" id="qty-${index}" min="1" value="1">
            <button onclick="addToCart('${product.img}', ${product.price}, ${index})">Add to Cart</button>
        </div>
    `).join('');
}

function addToCart(img, price, index) {
    const quantity = parseInt(document.getElementById(`qty-${index}`).value);
    const existingItem = cart.find(item => item.img === img);

    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        cart.push({ img, price, quantity });
    }

    updateCart();
}

function updateCart() {
    let cartHTML = '';
    let total = 0;

    cart.forEach((item, index) => {
        total += item.price * item.quantity;
        cartHTML += `
            <div class="cart-item">
                <img src="${item.img}" alt="Cart Product">
                <p>₹${item.price} x ${item.quantity}</p>
                <button onclick="removeFromCart(${index})">Remove</button>
            </div>
        `;
    });

    cartHTML += `<h3>Total: ₹${total}</h3>`;
    document.getElementById("cart").innerHTML = cartHTML;
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCart();
}
